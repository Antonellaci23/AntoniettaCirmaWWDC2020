//: [Previous](@previous)

/*:
# About Technologies
In this playground, I used the following frameworks: AVFoundation and UIKit.
 
 The [AVFoundation](https://developer.apple.com/documentation/avfoundation) framework for audiovisual media on Apple.
 
 The [UIKit](https://developer.apple.com/documentation/uikit) framework for graphic and user interface
 
 For more information, click on the links.

*/

//: [Next](@next)
