//: [Previous](@previous)

/*:
# About Graphic
In this playground, the assets used are partly taken from platforms that have free distribution of images and sounds, such as image1.png, image2.png and image3.png, sunnyDay.mp3 and fireworks.mp3. The remaining assets were produced by me.

 
I chose the summer theme because it is my favorite season knowing that we will live differently this year because of Covid-19. My intention is to give a summer feeling while playing so that, at least for a few minutes, you can immerse yourself in a relaxed and exotic environment, adjectives that I have always associated with the summer season.

*/

//: [Next](@next)
